package com.example.week8

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView

class Main2Activity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main2)

        val txtShow = findViewById<TextView>(R.id.txtShow)

        var strShow: String = intent.getStringExtra("SendStuff")
        txtShow.text = strShow
    }
}
